Este es un ejemplo practico de para que nos sirve pasar el formulario por un template antes de sacarlo por pantalla:

<div class="contenedor">

	<div class="izquierda">
		<!-- Si comentas esta linea vas a ver que se sigue dibujando el formulario entero -->
		<?php echo drupal_render($form["apellido"]); ?>
		<?php echo drupal_render($form["mail"]); ?>
	</div>
	
	
	<div class="derecha">
		<?php echo drupal_render($form["telefono"]); ?>
		<?php echo drupal_render($form["nombre"]); ?>
	</div>

<div class="clear">&nbsp;</div>
	
		<!-- si comentas esta linea vas a ver como el resto de los elementos del formulario no se dibujan -->
		<?php echo drupal_render($form); ?>
		
<div class="clear">&nbsp;</div>
</div>